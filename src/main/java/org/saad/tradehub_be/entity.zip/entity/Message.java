package org.saad.tradehub_be.entity;

public class Message {
    private String messageText;
}
